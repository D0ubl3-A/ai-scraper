#!/usr/bin/env python3
"""
AI Scraper Examples - Different use cases and custom prompts
"""

from ai_scraper_system import AIScraper
import os

def example_product_scraping():
    """Example: Scrape product pages and extract key information"""
    print("🛍️ Product Scraping Example")
    print("-" * 40)
    
    scraper = AIScraper()
    
    # Product URLs (example)
    urls = [
        "https://example-store.com/product1",
        "https://example-store.com/product2"
    ]
    
    custom_prompt = """
    Extract product information from this webpage:
    1. Product name and price
    2. Key features and specifications
    3. Customer rating/reviews summary
    4. Availability status
    5. Product category
    
    Format as a structured product summary.
    """
    
    results = scraper.scrape_multiple_urls(urls, custom_prompt)
    scraper.save_results(results, "product_analysis", "csv")
    
    return results

def example_news_scraping():
    """Example: Scrape news articles and summarize"""
    print("📰 News Scraping Example")
    print("-" * 40)
    
    scraper = AIScraper()
    
    # News URLs (example)
    urls = [
        "https://news-site.com/article1",
        "https://news-site.com/article2"
    ]
    
    custom_prompt = """
    Analyze this news article and provide:
    1. Article headline and main topic
    2. Key facts and important details
    3. People or organizations mentioned
    4. Date/time relevance
    5. Brief 2-sentence summary
    
    Focus on factual information only.
    """
    
    results = scraper.scrape_multiple_urls(urls, custom_prompt)
    scraper.save_results(results, "news_summary", "txt")
    
    return results

def example_competitor_analysis():
    """Example: Analyze competitor websites"""
    print("🔍 Competitor Analysis Example")
    print("-" * 40)
    
    scraper = AIScraper()
    
    # Competitor URLs
    urls = [
        "https://competitor1.com",
        "https://competitor2.com",
        "https://competitor3.com"
    ]
    
    custom_prompt = """
    Analyze this competitor website and identify:
    1. Main products/services offered
    2. Target audience and positioning
    3. Key value propositions mentioned
    4. Pricing strategy (if visible)
    5. Unique features or differentiators
    6. Overall website quality and user experience
    
    Provide insights for competitive analysis.
    """
    
    results = scraper.scrape_multiple_urls(urls, custom_prompt)
    scraper.save_results(results, "competitor_analysis", "json")
    
    return results

def example_content_research():
    """Example: Research content for blog topics"""
    print("📝 Content Research Example")
    print("-" * 40)
    
    scraper = AIScraper()
    
    # Research URLs
    urls = [
        "https://blog1.com/topic",
        "https://blog2.com/related-topic",
        "https://resource-site.com/guide"
    ]
    
    custom_prompt = """
    Analyze this content for research purposes:
    1. Main topics and subtopics covered
    2. Key insights or data points
    3. Expert opinions or quotes
    4. Trending themes or patterns
    5. Content gaps or opportunities
    6. Actionable takeaways
    
    Provide research insights for content creation.
    """
    
    results = scraper.scrape_multiple_urls(urls, custom_prompt)
    scraper.save_results(results, "content_research", "txt")
    
    return results

def example_lead_generation():
    """Example: Extract contact information and company details"""
    print("📞 Lead Generation Example")
    print("-" * 40)
    
    scraper = AIScraper()
    
    # Company websites
    urls = [
        "https://company1.com/about",
        "https://company2.com/contact",
        "https://company3.com"
    ]
    
    custom_prompt = """
    Extract business information for lead generation:
    1. Company name and industry
    2. Contact information (email, phone, address)
    3. Key personnel or decision makers
    4. Company size and revenue indicators
    5. Products/services offered
    6. Business model and target market
    
    Format as a lead qualification summary.
    """
    
    results = scraper.scrape_multiple_urls(urls, custom_prompt)
    scraper.save_results(results, "lead_generation", "csv")
    
    return results

def custom_scraping_demo():
    """Interactive demo for custom scraping"""
    print("🎯 Custom Scraping Demo")
    print("-" * 40)
    
    # Get user input
    print("Enter URLs to scrape (one per line, empty line to finish):")
    urls = []
    while True:
        url = input("URL: ").strip()
        if not url:
            break
        urls.append(url)
    
    if not urls:
        print("No URLs provided. Using example URLs.")
        urls = ["https://httpbin.org/html", "https://example.com"]
    
    print("\nEnter your custom AI processing prompt:")
    custom_prompt = input("Prompt: ").strip()
    
    if not custom_prompt:
        custom_prompt = "Summarize the main content and purpose of this webpage."
    
    print(f"\n🚀 Processing {len(urls)} URLs with custom prompt...")
    
    scraper = AIScraper()
    results = scraper.scrape_multiple_urls(urls, custom_prompt)
    
    # Save results
    scraper.save_results(results, "custom_scraping", "json")
    scraper.save_results(results, "custom_scraping", "txt")
    
    print("\n✅ Custom scraping complete!")
    return results

def main():
    """Run example demonstrations"""
    print("🤖 AI-Powered Web Scraper - Examples")
    print("=" * 50)
    
    if not os.environ.get("GROQ_API_KEY"):
        print("❌ GROQ_API_KEY not found!")
        print("Set your API key: export GROQ_API_KEY='your-key-here'")
        return
    
    examples = {
        "1": ("Product Scraping", example_product_scraping),
        "2": ("News Analysis", example_news_scraping),
        "3": ("Competitor Analysis", example_competitor_analysis),
        "4": ("Content Research", example_content_research),
        "5": ("Lead Generation", example_lead_generation),
        "6": ("Custom Demo", custom_scraping_demo)
    }
    
    print("\nAvailable Examples:")
    for key, (name, _) in examples.items():
        print(f"{key}. {name}")
    
    choice = input("\nSelect example (1-6): ").strip()
    
    if choice in examples:
        name, func = examples[choice]
        print(f"\n🚀 Running: {name}")
        try:
            results = func()
            print(f"✅ {name} completed successfully!")
        except Exception as e:
            print(f"❌ Error: {e}")
    else:
        print("Invalid choice. Running custom demo...")
        custom_scraping_demo()

if __name__ == "__main__":
    main()