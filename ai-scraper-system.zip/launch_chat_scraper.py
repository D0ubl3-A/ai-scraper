#!/usr/bin/env python3
"""
Launch Script for AI Scraper Chat Interface
Simple one-command launcher for the complete chat system
"""

import os
import sys
import subprocess
import webbrowser
import time
import threading
from pathlib import Path

def check_dependencies():
    """Check if all required dependencies are installed"""
    required_packages = ['requests', 'beautifulsoup4', 'openai', 'lxml']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("❌ Missing required packages:")
        for package in missing_packages:
            print(f"   - {package}")
        print("\n📦 Install missing packages with:")
        print(f"   pip install {' '.join(missing_packages)}")
        return False
    
    return True

def check_files():
    """Check if all required files exist"""
    required_files = [
        'ai_scraper_system.py',
        'chat_scraper_interface.html', 
        'chat_api_handler.py'
    ]
    
    missing_files = []
    for file in required_files:
        if not Path(file).exists():
            missing_files.append(file)
    
    if missing_files:
        print("❌ Missing required files:")
        for file in missing_files:
            print(f"   - {file}")
        return False
    
    return True

def open_browser_delayed(url, delay=3):
    """Open browser after a delay"""
    time.sleep(delay)
    try:
        webbrowser.open(url)
        print(f"🌐 Opened browser: {url}")
    except Exception as e:
        print(f"⚠️  Could not open browser automatically: {e}")
        print(f"   Please manually open: {url}")

def main():
    """Main launcher function"""
    print("🚀 AI Scraper Chat Interface Launcher")
    print("=" * 50)
    
    # Check dependencies
    print("📦 Checking dependencies...")
    if not check_dependencies():
        return
    print("✅ All dependencies installed")
    
    # Check files
    print("📁 Checking required files...")
    if not check_files():
        return
    print("✅ All required files present")
    
    # Get port
    port = 8000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print("⚠️  Invalid port number, using default 8000")
    
    # Check if port is available
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if s.connect_ex(('localhost', port)) == 0:
            print(f"⚠️  Port {port} is already in use")
            port = port + 1
            print(f"🔄 Trying port {port} instead")
    
    print(f"🌐 Starting server on port {port}...")
    
    # Start browser opener in background
    url = f"http://localhost:{port}"
    browser_thread = threading.Thread(target=open_browser_delayed, args=(url, 2))
    browser_thread.daemon = True
    browser_thread.start()
    
    # Start the server
    try:
        from chat_api_handler import start_chat_server
        start_chat_server(port)
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
    except Exception as e:
        print(f"❌ Error starting server: {e}")

if __name__ == "__main__":
    main()