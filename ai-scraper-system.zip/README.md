# 🤖 AI-Powered Web Scraper System

**Intelligent web scraping with custom AI processing using Groq's lightning-fast models**

## 🚀 What Makes This Special?

This isn't just another web scraper. It combines traditional web scraping with AI-powered analysis to extract meaningful insights from any webpage. Perfect for research, competitive analysis, lead generation, and content creation.

## ✨ Features

- **🌐 Smart Web Scraping**: Extract titles, content, links, images, and metadata from any webpage
- **🤖 AI-Powered Analysis**: Process scraped data with Groq's lightning-fast AI models
- **💬 Interactive Chat Interface**: Real-time chat with AI scraper assistant
- **⚡ Lightning Fast**: Get AI analysis results in under 500ms
- **📊 Multiple Output Formats**: Export as JSON, CSV, or TXT files
- **🔧 Highly Customizable**: Create custom AI prompts for any use case
- **🛡️ Production Ready**: Robust error handling and session management

## 🎯 Use Cases

- **🛍️ E-commerce Analysis**: Extract product details, prices, reviews, and competitive positioning
- **📰 News Monitoring**: Scrape articles and generate summaries, sentiment analysis
- **🔍 Competitor Research**: Analyze competitor websites for services, pricing, positioning
- **📞 Lead Generation**: Extract contact information and company details
- **📝 Content Research**: Gather insights for blog topics and identify content gaps
- **🎯 SEO Analysis**: Analyze webpage structure, keywords, and optimization opportunities

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Set Your Groq API Key

Get your free API key from [Groq Console](https://console.groq.com/keys)

```bash
export GROQ_API_KEY='your-api-key-here'
```

### 3. Launch the Chat Interface

```bash
python launch_chat_scraper.py
```

This will:
- Start the HTTP server on port 8000
- Automatically open your browser to the chat interface
- Enable real-time AI scraping with chat commands

### 4. Alternative: Use Python API Directly

```python
from ai_scraper_system import AIScraper

# Initialize with your API key
scraper = AIScraper()

# Scrape and analyze with custom AI prompt
urls = ["https://competitor.com", "https://news-site.com"]
custom_prompt = "Extract key business insights and competitive advantages"

results = scraper.scrape_multiple_urls(urls, custom_prompt)
scraper.save_results(results, "analysis", "csv")
```

## 📁 File Structure

```
ai-scraper-system/
├── ai_scraper_system.py          # Core scraper with AI integration
├── chat_scraper_interface.html   # Interactive web chat interface
├── chat_api_handler.py           # HTTP server with API endpoints
├── launch_chat_scraper.py        # One-command launcher
├── scraper_examples.py           # Ready-to-use examples
├── test_ai_scraper.py            # Comprehensive test suite
├── requirements.txt              # Python dependencies
└── README.md                     # This file
```

## 💡 Chat Interface Features

### Quick Prompt Templates
- **🛍️ Product Analysis**: Extract product details, prices, and reviews
- **📰 News Summary**: Summarize articles and identify key points
- **🔍 Competitor Analysis**: Analyze positioning and strategies
- **📞 Lead Generation**: Extract contact info and company details
- **🎯 SEO Analysis**: Keywords and optimization opportunities
- **📝 Content Research**: Gather insights for content creation

### Custom Prompts
Enter any URL and custom analysis prompt:
```
URL: https://example.com
Prompt: Analyze this website's pricing strategy and target audience
```

## 🔧 Configuration

### Environment Variables
- `GROQ_API_KEY`: Your Groq API key (required)
- `SCRAPER_PORT`: Server port (default: 8000)
- `SCRAPER_HOST`: Server host (default: localhost)

### API Models Available
- `llama-3.1-8b-instant` (fastest, recommended)
- `llama-3.3-70b-versatile` (most capable)
- `mixtral-8x7b-32768` (balanced)
- `gemma2-9b-it` (efficient)

## 🧪 Testing

Run the comprehensive test suite:

```bash
python test_ai_scraper.py
```

This will test:
- API key validation
- Web scraping functionality
- AI processing capabilities
- Output format generation
- Error handling

## 📊 Example Usage Scenarios

### 1. E-commerce Product Analysis
```python
urls = ["https://store.com/product1", "https://store.com/product2"]
prompt = """
Extract product information:
1. Product name and price
2. Key features and specifications
3. Customer rating/reviews summary
4. Availability status
"""
```

### 2. Competitor Research
```python
urls = ["https://competitor1.com", "https://competitor2.com"]
prompt = """
Analyze competitor websites:
1. Main products/services offered
2. Target audience and positioning
3. Pricing strategy (if visible)
4. Unique differentiators
"""
```

### 3. News Monitoring
```python
urls = ["https://news-site.com/article1", "https://news-site.com/article2"]
prompt = """
Analyze news articles:
1. Article headline and main topic
2. Key facts and important details
3. People or organizations mentioned
4. Brief 2-sentence summary
"""
```

## 🔒 Security & Best Practices

- **API Key Security**: Never commit API keys to version control
- **Rate Limiting**: Built-in delays between requests to respect server limits
- **Error Handling**: Comprehensive error handling for network issues
- **Session Management**: Persistent sessions for efficient scraping
- **CORS Support**: Secure cross-origin requests for web interface

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📄 License

This project is open source and available under the MIT License.

## 🆘 Support

- **Issues**: Report bugs or request features via GitHub Issues
- **Documentation**: Check the inline code documentation
- **Examples**: See `scraper_examples.py` for detailed usage examples

## 🚀 Deployment Options

### Local Development
```bash
python launch_chat_scraper.py
```

### Production Deployment
- Deploy `chat_scraper_interface.html` to any static hosting
- Run `chat_api_handler.py` on your server
- Configure CORS settings for your domain

---

**🎉 Ready to start scraping with AI? Get your [Groq API key](https://console.groq.com/keys) and launch the system!**