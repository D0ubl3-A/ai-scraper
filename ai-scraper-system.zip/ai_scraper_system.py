#!/usr/bin/env python3
"""
AI-Powered Web Scraper System
Combines web scraping with Groq AI for intelligent data extraction and custom output formatting
"""

import requests
from bs4 import BeautifulSoup
import json
import csv
import os
import time
from typing import Dict, List, Any, Optional
from openai import OpenAI
from urllib.parse import urljoin, urlparse
import re

class AIScraper:
    """
    AI-powered web scraper with Groq integration for intelligent data processing
    """
    
    def __init__(self, groq_api_key: Optional[str] = None):
        """Initialize the AI scraper with Groq API integration"""
        self.groq_api_key = groq_api_key or os.environ.get("GROQ_API_KEY")
        
        if not self.groq_api_key:
            raise ValueError("GROQ_API_KEY required for AI processing")
        
        # Initialize Groq client
        self.ai_client = OpenAI(
            api_key=self.groq_api_key,
            base_url="https://api.groq.com/openai/v1",
        )
        
        # Default headers for web requests
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        self.session = requests.Session()
        self.session.headers.update(self.headers)
    
    def scrape_url(self, url: str, timeout: int = 10) -> Dict[str, Any]:
        """
        Scrape a single URL and return structured data
        
        Args:
            url: URL to scrape
            timeout: Request timeout in seconds
            
        Returns:
            Dictionary with scraped data
        """
        try:
            print(f"🌐 Scraping: {url}")
            response = self.session.get(url, timeout=timeout)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract basic page data
            data = {
                'url': url,
                'title': soup.title.string.strip() if soup.title else '',
                'meta_description': '',
                'headings': [],
                'links': [],
                'text_content': '',
                'images': [],
                'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Extract meta description
            meta_desc = soup.find('meta', attrs={'name': 'description'})
            if meta_desc:
                data['meta_description'] = meta_desc.get('content', '')
            
            # Extract headings
            for i in range(1, 7):
                headings = soup.find_all(f'h{i}')
                for heading in headings:
                    data['headings'].append({
                        'level': i,
                        'text': heading.get_text().strip()
                    })
            
            # Extract links
            links = soup.find_all('a', href=True)
            for link in links[:50]:  # Limit to first 50 links
                href = link['href']
                full_url = urljoin(url, href)
                data['links'].append({
                    'text': link.get_text().strip(),
                    'url': full_url
                })
            
            # Extract images
            images = soup.find_all('img', src=True)
            for img in images[:20]:  # Limit to first 20 images
                src = img['src']
                full_url = urljoin(url, src)
                data['images'].append({
                    'src': full_url,
                    'alt': img.get('alt', ''),
                    'title': img.get('title', '')
                })
            
            # Extract main text content
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            data['text_content'] = soup.get_text()
            
            # Clean up text content
            lines = (line.strip() for line in data['text_content'].splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            data['text_content'] = ' '.join(chunk for chunk in chunks if chunk)
            
            print(f"✅ Successfully scraped: {len(data['text_content'])} characters")
            return data
            
        except Exception as e:
            print(f"❌ Error scraping {url}: {e}")
            return {
                'url': url,
                'error': str(e),
                'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S')
            }
    
    def ai_process_data(self, scraped_data: Dict[str, Any], custom_prompt: str, model: str = "llama-3.1-8b-instant") -> str:
        """
        Process scraped data using AI for custom output formatting
        
        Args:
            scraped_data: Data from scraping
            custom_prompt: Custom instructions for AI processing
            model: Groq model to use
            
        Returns:
            AI-processed output
        """
        try:
            # Prepare data for AI processing
            content_summary = {
                'title': scraped_data.get('title', ''),
                'description': scraped_data.get('meta_description', ''),
                'headings': [h['text'] for h in scraped_data.get('headings', [])[:10]],
                'text_preview': scraped_data.get('text_content', '')[:2000],  # First 2000 chars
                'link_count': len(scraped_data.get('links', [])),
                'image_count': len(scraped_data.get('images', []))
            }
            
            # Create AI prompt
            ai_prompt = f"""
You are an AI assistant helping to process scraped web data. Here's the data from a webpage:

URL: {scraped_data.get('url', 'Unknown')}
Title: {content_summary['title']}
Description: {content_summary['description']}
Headings: {', '.join(content_summary['headings'])}
Text Preview: {content_summary['text_preview']}
Links Found: {content_summary['link_count']}
Images Found: {content_summary['image_count']}

Custom Instructions: {custom_prompt}

Please process this data according to the custom instructions and provide a well-formatted response.
"""
            
            print("🤖 Processing with AI...")
            response = self.ai_client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": ai_prompt}],
                max_tokens=1000,
                temperature=0.7
            )
            
            ai_output = response.choices[0].message.content
            print("✅ AI processing complete")
            return ai_output
            
        except Exception as e:
            print(f"❌ AI processing error: {e}")
            return f"Error processing data: {str(e)}"
    
    def scrape_multiple_urls(self, urls: List[str], custom_prompt: str, output_format: str = "json") -> List[Dict[str, Any]]:
        """
        Scrape multiple URLs and process with AI
        
        Args:
            urls: List of URLs to scrape
            custom_prompt: Custom AI processing instructions
            output_format: Output format (json, csv, txt)
            
        Returns:
            List of processed results
        """
        results = []
        
        for i, url in enumerate(urls, 1):
            print(f"\n📊 Processing {i}/{len(urls)}: {url}")
            
            # Scrape the URL
            scraped_data = self.scrape_url(url)
            
            if 'error' not in scraped_data:
                # Process with AI
                ai_output = self.ai_process_data(scraped_data, custom_prompt)
                
                result = {
                    'url': url,
                    'scraped_data': scraped_data,
                    'ai_output': ai_output,
                    'processed_at': time.strftime('%Y-%m-%d %H:%M:%S')
                }
            else:
                result = {
                    'url': url,
                    'error': scraped_data['error'],
                    'processed_at': time.strftime('%Y-%m-%d %H:%M:%S')
                }
            
            results.append(result)
            
            # Small delay between requests
            time.sleep(1)
        
        return results
    
    def save_results(self, results: List[Dict[str, Any]], filename: str, format_type: str = "json"):
        """
        Save results to file in specified format
        
        Args:
            results: Processed results
            filename: Output filename
            format_type: File format (json, csv, txt)
        """
        try:
            if format_type.lower() == "json":
                with open(f"{filename}.json", 'w', encoding='utf-8') as f:
                    json.dump(results, f, indent=2, ensure_ascii=False)
                print(f"✅ Results saved to {filename}.json")
                
            elif format_type.lower() == "csv":
                with open(f"{filename}.csv", 'w', newline='', encoding='utf-8') as f:
                    if results:
                        writer = csv.DictWriter(f, fieldnames=['url', 'ai_output', 'processed_at'])
                        writer.writeheader()
                        for result in results:
                            writer.writerow({
                                'url': result.get('url', ''),
                                'ai_output': result.get('ai_output', ''),
                                'processed_at': result.get('processed_at', '')
                            })
                print(f"✅ Results saved to {filename}.csv")
                
            elif format_type.lower() == "txt":
                with open(f"{filename}.txt", 'w', encoding='utf-8') as f:
                    for result in results:
                        f.write(f"URL: {result.get('url', '')}\n")
                        f.write(f"Processed: {result.get('processed_at', '')}\n")
                        f.write(f"AI Output:\n{result.get('ai_output', '')}\n")
                        f.write("-" * 80 + "\n\n")
                print(f"✅ Results saved to {filename}.txt")
                
        except Exception as e:
            print(f"❌ Error saving results: {e}")

def main():
    """Demo of the AI scraper system"""
    print("🚀 AI-Powered Web Scraper System")
    print("=" * 50)
    
    # Example usage
    try:
        scraper = AIScraper()
        
        # Example URLs to scrape
        urls = [
            "https://example.com",
            "https://httpbin.org/html",
            "https://quotes.toscrape.com/"
        ]
        
        # Custom AI processing prompt
        custom_prompt = """
        Analyze this webpage and provide:
        1. A brief summary of the main content
        2. Key topics or themes identified
        3. Any notable features or elements
        4. Overall assessment of the page's purpose
        
        Format the response as a structured summary.
        """
        
        # Process URLs
        results = scraper.scrape_multiple_urls(urls, custom_prompt)
        
        # Save results
        scraper.save_results(results, "scraping_results", "json")
        scraper.save_results(results, "scraping_results", "csv")
        
        print(f"\n🎉 Completed! Processed {len(results)} URLs")
        
    except ValueError as e:
        print(f"❌ Configuration Error: {e}")
        print("💡 Please set your GROQ_API_KEY environment variable")
    except Exception as e:
        print(f"❌ System Error: {e}")

if __name__ == "__main__":
    main()