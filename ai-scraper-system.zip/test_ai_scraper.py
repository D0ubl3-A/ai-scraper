#!/usr/bin/env python3
"""
Quick test of AI Scraper System with working examples
"""

from ai_scraper_system import AIScraper
import os

def test_ai_scraper():
    """Test the AI scraper with sample data"""
    print("🧪 Testing AI Scraper System")
    print("=" * 50)
    
    # Initialize scraper
    scraper = AIScraper()
    
    # Create sample scraped data (simulating a successful scrape)
    sample_data = {
        'url': 'https://example.com',
        'title': 'Example Domain - Technology Blog',
        'meta_description': 'A technology blog covering AI, web development, and digital trends',
        'headings': [
            {'level': 1, 'text': 'Welcome to Tech Blog'},
            {'level': 2, 'text': 'Latest AI Developments'},
            {'level': 2, 'text': 'Web Development Trends'},
            {'level': 3, 'text': 'Python Programming Tips'}
        ],
        'text_content': 'Welcome to our technology blog. We cover the latest developments in artificial intelligence, machine learning, web development, and digital transformation. Our team of experts provides insights into emerging technologies, programming tutorials, and industry analysis. Recent topics include GPT models, React frameworks, cloud computing, and cybersecurity best practices.',
        'links': [
            {'text': 'AI Articles', 'url': 'https://example.com/ai'},
            {'text': 'Web Dev', 'url': 'https://example.com/webdev'},
            {'text': 'Contact', 'url': 'https://example.com/contact'}
        ],
        'images': [
            {'src': 'https://example.com/logo.png', 'alt': 'Tech Blog Logo'},
            {'src': 'https://example.com/ai-banner.jpg', 'alt': 'AI Technology'}
        ],
        'scraped_at': '2025-12-09 14:30:00'
    }
    
    print("📊 Sample Data Created")
    print(f"Title: {sample_data['title']}")
    print(f"Content Length: {len(sample_data['text_content'])} characters")
    
    # Test different AI processing prompts
    test_prompts = [
        {
            'name': 'Content Summary',
            'prompt': 'Provide a brief summary of this webpage content and identify the main topics covered.'
        },
        {
            'name': 'SEO Analysis', 
            'prompt': 'Analyze this webpage for SEO purposes: identify keywords, content structure, and optimization opportunities.'
        },
        {
            'name': 'Competitor Research',
            'prompt': 'Analyze this website as a competitor: what are their main offerings, target audience, and competitive advantages?'
        },
        {
            'name': 'Lead Generation',
            'prompt': 'Extract business information for lead generation: company focus, services offered, and potential contact opportunities.'
        }
    ]
    
    results = []
    
    for test in test_prompts:
        print(f"\n🤖 Testing: {test['name']}")
        print("-" * 30)
        
        ai_output = scraper.ai_process_data(sample_data, test['prompt'])
        
        result = {
            'test_name': test['name'],
            'prompt': test['prompt'],
            'ai_output': ai_output,
            'url': sample_data['url']
        }
        
        results.append(result)
        print(f"✅ {test['name']} completed")
        print(f"Output preview: {ai_output[:100]}...")
    
    # Save test results
    scraper.save_results(results, "ai_scraper_test", "json")
    scraper.save_results(results, "ai_scraper_test", "txt")
    
    print(f"\n🎉 All tests completed! {len(results)} AI processing tests successful")
    print("📁 Results saved to ai_scraper_test.json and ai_scraper_test.txt")
    
    return results

def demo_custom_processing():
    """Demo custom AI processing with user input"""
    print("\n🎯 Custom AI Processing Demo")
    print("=" * 40)
    
    scraper = AIScraper()
    
    # Sample e-commerce data
    ecommerce_data = {
        'url': 'https://shop-example.com/product/laptop',
        'title': 'Gaming Laptop Pro X1 - High Performance Computing',
        'meta_description': 'Professional gaming laptop with RTX graphics, 32GB RAM, and ultra-fast SSD storage',
        'headings': [
            {'level': 1, 'text': 'Gaming Laptop Pro X1'},
            {'level': 2, 'text': 'Technical Specifications'},
            {'level': 2, 'text': 'Customer Reviews'},
            {'level': 3, 'text': 'Performance Benchmarks'}
        ],
        'text_content': 'Gaming Laptop Pro X1 features Intel i9 processor, NVIDIA RTX 4080 graphics card, 32GB DDR5 RAM, 1TB NVMe SSD storage. Price: $2,499. Customer rating: 4.8/5 stars based on 156 reviews. Free shipping available. 2-year warranty included. Perfect for gaming, content creation, and professional work.',
        'links': [
            {'text': 'Buy Now', 'url': 'https://shop-example.com/cart/add'},
            {'text': 'Compare Models', 'url': 'https://shop-example.com/compare'},
            {'text': 'Reviews', 'url': 'https://shop-example.com/reviews'}
        ],
        'scraped_at': '2025-12-09 14:35:00'
    }
    
    # Custom processing examples
    custom_prompts = [
        "Extract product details: name, price, key specs, and customer rating. Format as a product comparison table.",
        "Analyze this product page for conversion optimization: identify trust signals, pricing strategy, and call-to-action effectiveness.",
        "Create a competitive analysis summary: what makes this product unique and how does it position against competitors?"
    ]
    
    for i, prompt in enumerate(custom_prompts, 1):
        print(f"\n📝 Custom Processing {i}/3")
        print(f"Prompt: {prompt}")
        
        ai_output = scraper.ai_process_data(ecommerce_data, prompt)
        print(f"✅ AI Output:\n{ai_output}\n")
        print("-" * 50)

def main():
    """Run AI scraper tests"""
    if not os.environ.get("GROQ_API_KEY"):
        print("❌ GROQ_API_KEY not found!")
        print("Set your API key: export GROQ_API_KEY='your-key-here'")
        return
    
    try:
        # Run main test
        test_ai_scraper()
        
        # Run custom demo
        demo_custom_processing()
        
        print("\n🚀 AI Scraper System fully tested and operational!")
        
    except Exception as e:
        print(f"❌ Test error: {e}")

if __name__ == "__main__":
    main()