#!/usr/bin/env python3
"""
Chat API Handler for AI Scraper
Provides a simple HTTP server to handle chat requests from the web interface
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import urllib.parse
from ai_scraper_system import AIScraper
import os
import threading
import time

class ChatAPIHandler(BaseHTTPRequestHandler):
    """HTTP request handler for chat API"""
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_POST(self):
        """Handle POST requests for scraping"""
        try:
            # Parse request
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            
            # Extract parameters
            url = data.get('url', '').strip()
            prompt = data.get('prompt', '').strip()
            api_key = data.get('api_key', '').strip()
            
            if not all([url, prompt, api_key]):
                self.send_error_response("Missing required parameters: url, prompt, or api_key")
                return
            
            # Initialize scraper with provided API key
            scraper = AIScraper(groq_api_key=api_key)
            
            # Scrape the URL
            print(f"🌐 Scraping: {url}")
            scraped_data = scraper.scrape_url(url)
            
            if 'error' in scraped_data:
                self.send_error_response(f"Scraping failed: {scraped_data['error']}")
                return
            
            # Process with AI
            print(f"🤖 Processing with AI: {prompt}")
            ai_output = scraper.ai_process_data(scraped_data, prompt)
            
            # Prepare response
            response_data = {
                'success': True,
                'url': url,
                'prompt': prompt,
                'scraped_data': {
                    'title': scraped_data.get('title', ''),
                    'meta_description': scraped_data.get('meta_description', ''),
                    'text_length': len(scraped_data.get('text_content', '')),
                    'links_count': len(scraped_data.get('links', [])),
                    'images_count': len(scraped_data.get('images', [])),
                    'scraped_at': scraped_data.get('scraped_at', '')
                },
                'ai_analysis': ai_output,
                'processed_at': time.strftime('%Y-%m-%d %H:%M:%S')
            }
            
            self.send_json_response(response_data)
            print("✅ Request processed successfully")
            
        except json.JSONDecodeError:
            self.send_error_response("Invalid JSON in request body")
        except Exception as e:
            print(f"❌ Error processing request: {e}")
            self.send_error_response(f"Server error: {str(e)}")
    
    def do_GET(self):
        """Handle GET requests"""
        if self.path == '/':
            self.serve_chat_interface()
        elif self.path == '/health':
            self.send_json_response({'status': 'healthy', 'service': 'AI Scraper Chat API'})
        else:
            self.send_error_response("Endpoint not found", 404)
    
    def serve_chat_interface(self):
        """Serve the chat interface HTML"""
        try:
            with open('chat_scraper_interface.html', 'r', encoding='utf-8') as f:
                html_content = f.read()
            
            # Inject API endpoint into the HTML
            html_content = html_content.replace(
                'await simulateAIScraping(url, prompt);',
                'await callRealAPI(url, prompt);'
            )
            
            # Add real API call function
            api_script = """
            async function callRealAPI(url, prompt) {
                try {
                    const response = await fetch('/scrape', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            url: url,
                            prompt: prompt,
                            api_key: apiKey
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        const resultHtml = `
                            <strong>✅ Analysis Complete!</strong><br><br>
                            <strong>URL Analyzed:</strong> ${result.url}<br>
                            <strong>Page Title:</strong> ${result.scraped_data.title}<br>
                            <strong>Content Length:</strong> ${result.scraped_data.text_length} characters<br>
                            <strong>Links Found:</strong> ${result.scraped_data.links_count}<br>
                            <strong>Images Found:</strong> ${result.scraped_data.images_count}<br><br>
                            <strong>AI Analysis:</strong><br>
                            ${result.ai_analysis.replace(/\\n/g, '<br>')}<br><br>
                            <div class="result-actions">
                                <button class="action-btn" onclick="downloadResult('json', '${JSON.stringify(result).replace(/'/g, "\\'")}')">📥 Download JSON</button>
                                <button class="action-btn" onclick="copyResult('${result.ai_analysis.replace(/'/g, "\\'")}')">📋 Copy Result</button>
                            </div>
                        `;
                        addBotMessage(resultHtml, true);
                    } else {
                        addBotMessage(`❌ Error: ${result.error}`);
                    }
                } catch (error) {
                    addBotMessage(`❌ Network Error: ${error.message}`);
                }
            }
            
            function downloadResult(format, data) {
                const blob = new Blob([data], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `scraping_result_${Date.now()}.${format}`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }
            
            function copyResult(text) {
                navigator.clipboard.writeText(text).then(() => {
                    alert('Result copied to clipboard!');
                }).catch(() => {
                    alert('Failed to copy to clipboard');
                });
            }
            """
            
            html_content = html_content.replace('</script>', api_script + '\n</script>')
            
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(html_content.encode('utf-8'))
            
        except FileNotFoundError:
            self.send_error_response("Chat interface file not found", 404)
    
    def send_json_response(self, data, status_code=200):
        """Send JSON response with CORS headers"""
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode('utf-8'))
    
    def send_error_response(self, message, status_code=400):
        """Send error response"""
        error_data = {
            'success': False,
            'error': message,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
        }
        self.send_json_response(error_data, status_code)
    
    def log_message(self, format, *args):
        """Override to customize logging"""
        print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {format % args}")

def start_chat_server(port=8000):
    """Start the chat API server"""
    server_address = ('', port)
    httpd = HTTPServer(server_address, ChatAPIHandler)
    
    print(f"🚀 AI Scraper Chat Server Starting...")
    print(f"🌐 Server running at: http://localhost:{port}")
    print(f"💬 Chat interface: http://localhost:{port}/")
    print(f"🔍 Health check: http://localhost:{port}/health")
    print(f"📡 API endpoint: http://localhost:{port}/scrape")
    print("=" * 60)
    print("📝 Usage:")
    print("1. Open http://localhost:{port}/ in your browser")
    print("2. Enter your Groq API key")
    print("3. Start chatting with the AI scraper!")
    print("=" * 60)
    print("Press Ctrl+C to stop the server")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
        httpd.server_close()

def main():
    """Main function to start the server"""
    import argparse
    
    parser = argparse.ArgumentParser(description='AI Scraper Chat Server')
    parser.add_argument('--port', type=int, default=8000, help='Port to run the server on (default: 8000)')
    args = parser.parse_args()
    
    # Check if required files exist
    required_files = ['ai_scraper_system.py', 'chat_scraper_interface.html']
    missing_files = [f for f in required_files if not os.path.exists(f)]
    
    if missing_files:
        print(f"❌ Missing required files: {', '.join(missing_files)}")
        print("Please ensure all AI scraper system files are in the current directory.")
        return
    
    start_chat_server(args.port)

if __name__ == "__main__":
    main()