#!/usr/bin/env python3
"""
Setup script for AI-Powered Web Scraper System
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="ai-scraper-system",
    version="1.0.0",
    author="AI Scraper Team",
    author_email="contact@example.com",
    description="AI-powered web scraper with custom output processing using Groq's lightning-fast models",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/ai-scraper-system",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Internet :: WWW/HTTP :: Indexing/Search",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "ai-scraper=launch_chat_scraper:main",
        ],
    },
    keywords="web scraping, ai, groq, data extraction, automation, analysis",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/ai-scraper-system/issues",
        "Source": "https://github.com/yourusername/ai-scraper-system",
        "Documentation": "https://github.com/yourusername/ai-scraper-system#readme",
    },
)